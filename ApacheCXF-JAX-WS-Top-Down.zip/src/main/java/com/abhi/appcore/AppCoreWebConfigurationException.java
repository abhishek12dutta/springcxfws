package com.abhi.appcore;


/**
 * Thrown when there is some problem with configuring the web application from
 * a captwo perspective.
 * @author Abhishek Dutta
 */
public class AppCoreWebConfigurationException extends RuntimeException {

    /**
     * Constructs an instance of the exception with the specified detail
     * @param s the message
     * @param throwable the exception
     */
    public AppCoreWebConfigurationException(String s, Throwable throwable) {
        super(s, throwable);
    }

    /**
     * Constructs an instance of the exception with the specified detail
     * @param s the message
     */
    public AppCoreWebConfigurationException(String s) {
        super(s);
    }
}
