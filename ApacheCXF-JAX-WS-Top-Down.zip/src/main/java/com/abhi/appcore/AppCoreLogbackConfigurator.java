package com.abhi.appcore;

import java.net.URL;

import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.joran.spi.JoranException;
import ch.qos.logback.core.util.StatusPrinter;

public class AppCoreLogbackConfigurator {
	
	 private static final String DEFAULT_CAPTWO_LOGBACK_FILENAME = "defaultwebapp-logback.xml";
	    private String defaultLogbackFilename = DEFAULT_CAPTWO_LOGBACK_FILENAME;

	    /**
	     * Configures logging using the specified logback file
	     *
	     * @param logbackBaseConfigFilename the logback file
	     */
	    public void doConfiguration(String logbackBaseConfigFilename) {

	        String primaryLogbackFilename = getPrimaryWebappLogbackFilename(logbackBaseConfigFilename);
	        URL fileUrl = Thread.currentThread().getContextClassLoader().getResource(primaryLogbackFilename);
	        
	        if (fileUrl == null) {
	            fileUrl = Thread.currentThread().getContextClassLoader().getResource(getDefaultLogbackFilename());
	        }

	        if (fileUrl == null) {
	            String errorMessage = "Application Server Environment not configured properly. "
	                    + "The Application Server should be configured to have the default captwo logback config file "
	                    + "(" + getDefaultLogbackFilename() + ") available on its classpath in case web apps do not "
	                    + "specify their own, please ensure this is done";
	            System.out.println(errorMessage);
	            throw new AppCoreWebConfigurationException(errorMessage);
	        }
	        configureLogbackWithFile(fileUrl);
	    }

	    private String getPrimaryWebappLogbackFilename(String logbackBaseConfigFilename) {
	        return logbackBaseConfigFilename + "-logback.xml";
	    }

	    private void configureLogbackWithFile(URL url) {
	        JoranConfigurator configurator = getJoranConfigurator();
	        LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
	        configurator.setContext(loggerContext);
	        loggerContext.reset();
	        try {
	            configurator.doConfigure(url);
	            StatusPrinter.print(loggerContext);
	        } catch (JoranException ex) {
	            throw new AppCoreWebConfigurationException("Unable to configure web app from file " + url.getFile() ,ex);
	        }
	    }

	    /**
	     * Gets default logback filename.
	     *
	     * @return the default logback filename
	     */
	    public String getDefaultLogbackFilename() {
	        return defaultLogbackFilename;
	    }

	    /**
	     * Sets default logback filename.
	     *
	     * @param defaultLogbackFilename the default logback filename
	     */
	    public void setDefaultLogbackFilename(String defaultLogbackFilename) {
	        this.defaultLogbackFilename = defaultLogbackFilename;
	    }

	    /**
	     * Returns a Joran Configurator. This method only exists so that we can mock
	     * out the creating of this object (from the JUNITs).
	     *
	     * @return the Joran Configurator object
	     */
	    protected JoranConfigurator getJoranConfigurator(){
	        return new JoranConfigurator();
	    }

}
