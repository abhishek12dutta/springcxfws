package com.abhi.appcore;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.LoggerContext;

import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;

public class AppCoreBootstrapServletContextListener implements ServletContextListener{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AppCoreBootstrapServletContextListener.class);
    private AppCoreLogbackConfigurator appCoreLogbackConfigurator = new AppCoreLogbackConfigurator();


	public void contextDestroyed(ServletContextEvent sce) {
		LOGGER.info("AppCoreBootstrapServletContextListener destroyed");
        ILoggerFactory ilc = LoggerFactory.getILoggerFactory();
        if (ilc instanceof LoggerContext) {
            LoggerContext lc = (LoggerContext) ilc;
            lc.stop();
        }
        appCoreLogbackConfigurator = null;
		
	}

	public void contextInitialized(ServletContextEvent sce) {
		LOGGER.info("AppCoreBootstrapServletContextListener started");
        String logbackBaseConfigFilename = sce.getServletContext().getInitParameter("logback-config-basefilename");
        appCoreLogbackConfigurator.doConfiguration(logbackBaseConfigFilename);
		
	}

}
