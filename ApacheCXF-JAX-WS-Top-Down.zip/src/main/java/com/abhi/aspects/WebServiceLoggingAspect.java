package com.abhi.aspects;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Map;

import javax.jws.WebMethod;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.AnnotationUtils;

import com.abhi.util.ApplicationTransportHeader;
import com.abhi.util.ServiceContextHolder;

@Aspect
public class WebServiceLoggingAspect {

	private static final Logger LOGGER = LoggerFactory.getLogger(WebServiceLoggingAspect.class);

	/**
	 * Debug level logging
	 */
	public WebServiceLoggingAspect() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Webservice aspect instantiated");
		}
	}

	@Pointcut("within(@javax.jws.WebService *)")
	public void beanAnnotatedWithWebService() {
	}

	@Pointcut("execution(public * *(..))")
	public void publicMethod() {
	}

	@Pointcut("publicMethod() && beanAnnotatedWithWebService()")
	public void publicMethodInsideAClassMarkedWithWebService() {
	}

	@Around("publicMethodInsideAClassMarkedWithWebService()")
	public Object logWebserviceCall(ProceedingJoinPoint jp) throws Throwable {
		Class callingClass = AspectUtils.getCallingClass(jp);
		String callingClassDetail = AspectUtils.getCallerInfoAsString(jp);

		Method method = ((MethodSignature) jp.getStaticPart().getSignature()).getMethod();

		Annotation operationNameAnnotation = AnnotationUtils.findAnnotation(method, WebMethod.class);

		String operationName = AnnotationUtils.getValue(operationNameAnnotation, "operationName").toString();

		Logger methodClassLogger = LoggerFactory.getLogger(callingClass.getName());

		// record this service as the current service in thread local
		Map<String, Object> serviceContext = ServiceContextHolder.getContext();
		// eg. /fli/flsc/ws/GetFlightAvailability
		String requestPath = (String) serviceContext.get("captwo.request.urlPath");
		serviceContext.put("captwo.service.current", requestPath + "(" + operationName + ")");
		// Store the operation so it can be retrieved and put on the header in
		// the outbound interceptor
		serviceContext.put(ApplicationTransportHeader.OPERATION_NAME, operationName);

		boolean exitThroughException = false;
		try {
			// DO NOT CHANGE THIS LOGGING FORMAT AS LOGSTASH (CTT) RELIES ON
			// THIS!
			methodClassLogger.info("TYPE+SOAPSERVICEENTRY|servicePath=" + requestPath + "|operation=" + operationName
					+ "|method=" + callingClassDetail);
			return jp.proceed();
		} catch (Throwable ex) {
			exitThroughException = true;
			// DO NOT CHANGE THIS LOGGING FORMAT AS LOGSTASH (CTT) RELIES ON
			// THIS!
			methodClassLogger.info("TYPE+SOAPSERVICEEXIT");
			throw ex;
		} finally {
			if (!exitThroughException) {
				// DO NOT CHANGE THIS LOGGING FORMAT AS LOGSTASH (CTT) RELIES ON
				// THIS!
				methodClassLogger.info("TYPE+SOAPSERVICEEXIT");
			}
		}
	}

}
