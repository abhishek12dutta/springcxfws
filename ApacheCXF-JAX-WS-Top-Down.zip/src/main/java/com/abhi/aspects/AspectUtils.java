package com.abhi.aspects;

import java.lang.annotation.Annotation;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AspectUtils {

	
	private static final Logger LOGGER = LoggerFactory
            .getLogger(AspectUtils.class);

	private AspectUtils() {
	}

	/**
	 * Returns a string representation of the calling class, method and line number
	 * @param jp the join point
	 * @return a string representation of the calling class, method and line number
	 */
	public static String getCallerInfoAsString(JoinPoint jp) {

		MethodSignature methodSignature = (MethodSignature)jp.getStaticPart().getSignature();
		String callingMethod = methodSignature.getName();
	    String callingClass = methodSignature.getDeclaringType().getName();

		String callingClassDetails = callingClass + "." + callingMethod;

		return callingClassDetails;
	}

    /**
     * Returns a string representation of the calling method
     * @param jp the join point
     * @return a string representation of the calling method
     */
    public static String getMethodAsString(JoinPoint jp) {

        MethodSignature methodSignature = (MethodSignature)jp.getStaticPart().getSignature();
        String callingMethod = methodSignature.getName();

        return callingMethod;
    }

    /**
     * Returns the method level annotation
     * @param jp the join point
     * @param classOfAnnotation the annotation class to look for
     * @return the annotation
     */
    public static Annotation getAnnotationValueAtMethodLevel(JoinPoint jp, Class classOfAnnotation) {

        MethodSignature methodSignature = (MethodSignature)jp.getStaticPart().getSignature();

        Annotation pathAnnotation = methodSignature.getMethod().getAnnotation(classOfAnnotation);
        return pathAnnotation;
    }

    /**
     * Returns the calling class associated with the joinpoint
     * @param jp the joinpoint
     * @return the calling class associated with the joinpoint
     */
    public static Class getCallingClass(JoinPoint jp) {
        Class callingClass = jp.getStaticPart().getSignature()
                .getDeclaringType();
        return callingClass;
    }
}
