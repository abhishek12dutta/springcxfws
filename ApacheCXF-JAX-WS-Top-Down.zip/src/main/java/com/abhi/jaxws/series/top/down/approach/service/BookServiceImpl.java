package com.abhi.jaxws.series.top.down.approach.service;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.apache.cxf.common.util.StringUtils;

import com.abhi.exception.FrameWorkError;
import com.abhi.exception.FrameworkException;
import com.abhi.logging.ApplicationLogger;

import in.benchresources.entities.book.BookRequestType;
import in.benchresources.entities.book.BookResponseType;
import in.benchresources.services.bookservice.IBookService;

@WebService(serviceName = "BookService", endpointInterface = "in.benchresources.services.bookservice.IBookService", targetNamespace = "http://benchresources.in/services/BookService/", portName = "BookServicePort", name = "BookServiceImpl")
public class BookServiceImpl implements IBookService {

	private static final ApplicationLogger LOGGER = ApplicationLogger.getLogger(BookServiceImpl.class);

	// http://localhost:8080/ApacheCXF-JAX-WS-Top-Down/services/book/BookService?wsdl

	@WebMethod(operationName = "getBookByISDNRequestNumber")
	public BookResponseType getBookByISDNRequestNumber(BookRequestType parameters) throws FrameworkException {
		
		LOGGER.debug("Entering getBookByISDNRequestNumber()");

		if (StringUtils.isEmpty(parameters.getIsbnNumber())) {
			throw new FrameworkException(FrameWorkError.IP_CONVERSION_ERROR, "IsbnNumber is null");
		}

		// create object of responseType and set values & return
		BookResponseType bookResponseType = new BookResponseType();
		bookResponseType.setBookISBN(parameters.getIsbnNumber());
		bookResponseType.setBookName("Objective Microbiology");
		bookResponseType.setAuthor("S. Nandi");
		bookResponseType.setCategory("Microbiology");
		
		LOGGER.debug("Exiting getBookByISDNRequestNumber()");
		return bookResponseType;
	}
}