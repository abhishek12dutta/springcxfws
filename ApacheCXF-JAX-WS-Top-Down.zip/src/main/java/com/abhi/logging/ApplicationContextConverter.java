package com.abhi.logging;

import java.util.Map;

import com.abhi.util.ApplicationTransportHeader;
import com.abhi.util.ServiceContextHolder;

import ch.qos.logback.classic.pattern.ClassicConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;

public class ApplicationContextConverter extends ClassicConverter {

	@Override
	public String convert(ILoggingEvent event) {
		String txId = "";
		String client = "";
		String entryService = "";
		String callingService = "";

		// check to see if we have calling context info setup..
		Map<String, Object> map = ServiceContextHolder.getContext();

		// if so, retrieve the captwoTxId, client & "mother service" details for
		// logging
		if (null != map) {
			String localTxId = (String) map.get(ApplicationTransportHeader.UNIQUE_TRANSACTION_ID);
			// avoid nulls getting printed
			txId = (null != localTxId) ? localTxId : txId;

			String localClient = (String) map.get(ApplicationTransportHeader.CLIENT_APPLICATION_NAME);
			// avoid nulls getting printed
			client = (null != localClient) ? localClient : client;

			String localEntryService = (String) map.get("captwo.service.entry");

			if (null != localEntryService) {
				entryService = localEntryService;
			}

			String localCallingService = (String) map.get("captwo.service.calling");

			if (null != localCallingService) {
				callingService = localCallingService;
			}
		}

		return "txId=" + txId + "|client=" + client + "|entryService=" + entryService + "|callingService="
				+ callingService;
	}

}
