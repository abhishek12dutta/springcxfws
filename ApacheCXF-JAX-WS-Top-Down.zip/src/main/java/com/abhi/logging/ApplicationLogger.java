package com.abhi.logging;

import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abhi.exception.FrameWorkError;
import com.abhi.util.LoggerUtility;

public class ApplicationLogger {

	private static final ConcurrentHashMap<String, ApplicationLogger> APPLICATION_LOGGERS = new ConcurrentHashMap<>();

	/**
	 * The underlying SLF4J logger
	 */
	private final Logger logger;

	/**
	 * Construct a new ApplicationLogger for the specified class
	 *
	 * @param aClassname
	 *            the name of the class
	 */
	private ApplicationLogger(String aClassname) {
		// create the underlying log4j logger so we log against the calling
		// class
		logger = LoggerFactory.getLogger(aClassname);
	}

	/**
	 * Retrieve the ApplicationLogger for the specified class.
	 * <p/>
	 * If no ApplicationLogger has been created then create one and cache it,
	 * otherwise return one from the cache
	 * <p/>
	 * TODO - consider using a synchronized HashMap
	 *
	 * @param aClassname
	 *            the name of the class
	 * @return the ApplicationLogger for the specified class
	 */
	public static synchronized ApplicationLogger getLogger(Class<?> aClassname) {
		ApplicationLogger cap2Logger = APPLICATION_LOGGERS.get(aClassname.getName());

		if (null == cap2Logger) {
			cap2Logger = new ApplicationLogger(aClassname.getName());
			APPLICATION_LOGGERS.put(aClassname.getName(), cap2Logger);
		}
		return cap2Logger;
	}

	/**
	 * Log a message at INFO Level.
	 *
	 * @param aMessage
	 *            the message
	 */
	public void info(String aMessage) {
		logger.info(aMessage);
	}

	/**
	 * Log a message at WARN Level. Note that all exceptions will be
	 * automatically logged as soon as they are thrown by the framework AOP
	 * infrastructure so you should only ever use this method to log warnings
	 * which should be recorded but should not cause a service to terminate
	 * processing.
	 *
	 * @param warning
	 *            the warning detail (represented as a CAPTWOError)
	 * @param additionalInfo
	 *            additional information associated with the warning
	 */
	public void warn(FrameWorkError warning, String additionalInfo) {
		String logMessage = LoggerUtility.generateLogWarnMessage(warning.getErrorCode(), warning.getErrorDescription(),
				additionalInfo);
		logger.warn(logMessage);

	}

	/**
	 * Returns true if debug is enabled
	 *
	 * @return true if debug is enabled, false otherwise
	 */
	public boolean isDebugEnabled() {
		return logger.isDebugEnabled();
	}

	/**
	 * Log a message at DEBUG Level.
	 *
	 * @param aMessage
	 *            the message
	 */
	public void debug(String aMessage) {
		logger.debug(aMessage);
	}

}
