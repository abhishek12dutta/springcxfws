package com.abhi.logging;

public enum ServiceType {

	REQ, RES;

	private ServiceType() {
	}

}
