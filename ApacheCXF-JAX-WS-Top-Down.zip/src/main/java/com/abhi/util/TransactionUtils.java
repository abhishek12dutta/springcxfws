package com.abhi.util;

import java.util.UUID;
import java.util.regex.Pattern;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TransactionUtils {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionUtils.class);
    private static final Pattern PATTERN = Pattern.compile("[a-zA-Z]+");

    private TransactionUtils() {
    }

    /**
     * Generates a unique timestamp
     *
     * @return String a unique timestamp
     */
    @NotNull
    private static synchronized String getUniqueTimeStamp() {
        return UUID.randomUUID().toString();
    }

    /**
     * Retrieves the server name from the env vars(Tomcat/Weblogic).
     * Currently we use both tomcat and weblogic so this should pick up one or the other.
     *
     * @return the server name
     */
    @NotNull
    private static String getServerName() {
        String server = "";
        if (null != System.getProperty("weblogic.Name")){
            server = System.getProperty("weblogic.Name");
        }
        if (null != System.getProperty("tomcat.Name")){
            server = System.getProperty("tomcat.Name");
        }
        return server;
    }


    /**
     * Generates a globally unique transaction id
     *
     * @return String a unique transaction id
     */
    public static String generateUniqueTransactionId() {
        String tid = "tx-" + PATTERN.matcher(getServerName()).replaceAll("") + '-' + getUniqueTimeStamp();

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("generated unique tx id is: {}", tid);
        }
        return tid;
    }

}
