package com.abhi.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Stores information about the service call in a thread local.
 *
 */
public final class ServiceContextHolder {

	/** thread local to hold general service information */
	private static final ThreadLocal<Map<String, Object>> SERVICE_CONTEXT_HOLDER = new ThreadLocal<Map<String, Object>>() {
		@Override
		protected Map<String, Object> initialValue() {
			// this method will be invoked the first time a thread
			// accesses the variable with a get() method
			return new HashMap<>(1);
		}
	};

	private ServiceContextHolder() {
	}

	/**
	 * Clears out the context for the current thread
	 */
	public static void clearContext() {
		SERVICE_CONTEXT_HOLDER.set(null);
		SERVICE_CONTEXT_HOLDER.remove();
	}

	/**
	 * Return the service context associated with the current thread
	 *
	 * @return the service context associated with the current thread
	 */
	public static Map<String, Object> getContext() {
		return SERVICE_CONTEXT_HOLDER.get();
	}

}