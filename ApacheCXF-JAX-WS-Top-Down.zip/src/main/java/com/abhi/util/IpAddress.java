package com.abhi.util;
import java.util.Arrays;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abhi.exception.FrameWorkError;

/**
 * Stores one IP Address
 *
 */
public class IpAddress {
	
	   private static final Logger LOGGER = LoggerFactory
	            .getLogger(IpAddress.class);

   // private static final CAPTWOLogger LOGGER = CAPTWOLogger.getLogger(IpAddress.class);
    private static final Pattern IP_PATTERN = Pattern
            .compile("(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){0,3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)");
    private final String[] octets = new String[4];
    private String ipAddress = "none";
    private long longValue;
    
    private static String ERROR_INVALID_IP="Can not convert (%d) to an IP address";

    /**
     * Sets this IpAddress passed on the IP passed on
     *
     * @see <a href="http://www.mkyong.com/java/java-and-0xff-example/">Java and â€œ& 0xFFâ€ example</a>
     * @see <a href="https://en.wikipedia.org/wiki/Bitwise_operation#AND">Wikipedia: Bitwise AND</a>
     * @see <a href="http://www.wikihow.com/Convert-from-Binary-to-Decimal">How to Convert from Binary to Decimal</a>
     * @see <a href="http://www.wikihow.com/Convert-from-Decimal-to-Binary">How to Convert from Decimal to Binary</a>
     * @see <a href="http://www.regular-expressions.info/tutorial.html">Regular Expressions Tutorial</a>
     */
    public IpAddress() {
    }

    /**
     * Sets this IpAddress passed on the IP passed on
     *
     * @param ip the IP address
     */
    public IpAddress(String ip) {
        setIpAddress(ip);
    }

    /**
     * Sets this IpAddress passed on the long passed on
     *
     * @param ip the IP address
     */
    public IpAddress(long ip) {

        // An IP is made up of 4 blocks of 1 byte (1 bit, ie.e. 8 characters 0|1)
        if (0L <= ip && 4294967295L >= ip) {
            longValue = ip;
            // shift by 24 bits (converts to binary; add 3x8=24 "0" (unset) bits from the left), only use the last 8 bits,
            // convert back to long and then to String
            octets[0] = Long.toString((ip >> 24) & 0xFF);
            octets[1] = Long.toString((ip >> 16) & 0xFF);
            octets[2] = Long.toString((ip >> 8) & 0xFF);
            octets[3] = Long.toString(ip & 0xFF);
            ipAddress = octets[0] + "." + octets[1] + "." + octets[2] + "."
                    + octets[3];
        } else {
            LOGGER.warn(LoggerUtility.generateLogWarnMessage(FrameWorkError.IP_CONVERSION_ERROR, String.format("Can not convert (%d) to an IP address")));
            longValue = -1;
        }
    }

    /**
     * Gets the IPAddress
     *
     * @return the IP address
     */
    public String getIpAddress() {
        return ipAddress;
    }

    /**
     * Sets the IPAddress
     *
     * @param ip the IP address
     */
    public void setIpAddress(String ip) {
        if (null != ip && IP_PATTERN.matcher(ip).matches()) {
            ipAddress = ip;
            setOctets();
            host2long();
        } else {
            LOGGER.warn(LoggerUtility.generateLogWarnMessage(FrameWorkError.INVALID_IP_ADDRESS, String.format("Invalid IP passed in (%s)", ip)));
            longValue = -1;
        }
    }

    /**
     * Converts an IP to a long value
     */
    private void host2long() {
        int[] addr = ip2intarray();
        for (int i = 0; i < addr.length; ++i) {
            longValue += (long) (0 <= addr[i] ? addr[i] : 0) << 8 * (3 - i);
        }
    }

    /**
     * Works out the value for each octet
     *
     * @return the octet value
     */
    @NotNull
    private int[] ip2intarray() {
        int[] address = {-1, -1, -1, -1};
        int i = 0;
        while (i < octets.length) {
            if (null != octets[i]) {
                address[i] = Integer.parseInt(octets[i]) & 0xFF;
            }
            i++;
        }
        return address;
    }

    /**
     * Gets the long value
     *
     * @return the long value
     */
    public long getLongValue() {
        return longValue;
    }

    /**
     * Sets the octets
     */
    private void setOctets() {
        StringTokenizer token = new StringTokenizer(ipAddress, ".");
        if (4 < token.countTokens()) { // can be lower than four as we might want to match blocks?
            return;
        }
        int i = 0;
        while (token.hasMoreTokens()) {
            String octet = token.nextToken();
            octets[i++] = octet;
        }
    }

    @Override
    public String toString() {
        return String.format("IpAddress [ipAddress=%s, octets=%s, longValue=%d]", ipAddress, Arrays.toString(octets), longValue);
    }

    // new

    /**
     * Checks if the IP address stored is valid or not.
     * (On the CAP, we check in if statements if longValue == -1, but according to {@link #IpAddress(long)} there is an
     * upper limit, too...)
     *
     * @return {@code true} if the IP is valid (i.e. within the numerical boundaries expected), {@code false} otherwise.
     */
    public boolean isInvalid() {
        return -1 == longValue || 4294967295L < longValue;
    }

    //new - see also ipRange.isIpWithinRange(ipAddress)

    /**
     * Checks whether the current IP address is within the range of IP addresses given (both sides included in the range)
     *
     * @param ipStart lower end
     * @param ipEnd   upper end
     * @return {@code true} if {@code this} IP address is within the range provided (both ends inclusive),
     * {@code false otherwise}
     * @see IpRange#isIpWithinRange(IpAddress)
     */
    public boolean isInRange(long ipStart, long ipEnd) {
        return longValue >= ipStart && longValue <= ipEnd;
    }

    // new - see also ipRange.isIpWithinRange(ipAddress)

    /**
     * Checks whether the current IP address is within the range of IP addresses given (both sides included in the range)
     *
     * @param ipStart lower end
     * @param ipEnd   upper end
     * @return {@code true} if {@code this} IP address is within the range provided (both ends inclusive),
     * {@code false otherwise}
     * @see IpRange#isIpWithinRange(IpAddress)
     */
    public boolean isInRange(IpAddress ipStart, IpAddress ipEnd) {
        return isInRange(ipStart.getLongValue(), ipEnd.getLongValue());
    }

    // new
    // todo: do overwrite equals and hashcode methods instead; cf. book Effective Java by Joshua Bloch

    /**
     * Checks if the IP address provided and {@code this} IP address match (i.e. have the same numerical value)
     * This method does not implement checks as rigorous as an overwritten {@link #equals(Object)} method would.
     * It does also not require {@link #hashCode()} to be overwritten
     *
     * @param compareTo IP address to compare {@code this} IP address to
     * @return {@code true} if the two IP addresses are numerically equal, {@code false} otherwise
     * @see #equals(Object) equals(Object) - to check if the objects are identical
     */
    public boolean matches(IpAddress compareTo) {
        return getLongValue() == compareTo.getLongValue();
    }
}