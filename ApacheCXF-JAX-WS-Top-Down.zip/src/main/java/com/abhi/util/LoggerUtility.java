package com.abhi.util;

import com.abhi.exception.FrameWorkError;

public class LoggerUtility {
	
	
	public static String generateLogWarnMessage(FrameWorkError frameWorkError,  String additionalInfo) {
        return generateLogWarnMessage(frameWorkError.getErrorCode(),frameWorkError.getErrorDescription(),additionalInfo);
    }
	
	public static String generateLogWarnMessage(String errorCode, String errorDescription, String additionalInfo) {
        return "TYPE+WARN|code=" + errorCode + "|desc=" + errorDescription + "(" + additionalInfo + ")" + "|lineNo=" + "0";
    }

}
