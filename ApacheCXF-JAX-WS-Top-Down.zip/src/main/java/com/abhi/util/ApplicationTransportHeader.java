package com.abhi.util;

public class ApplicationTransportHeader {
	
	 public static final String UNIQUE_TRANSACTION_ID = "unique_tx_id";
	 public static final String CLIENT_SESSIONID = "client_session_id";
	 public static final String REMOTE_CLIENT_IP_ADDRESS = "client_ip";
	 public static final String CLIENT_APPLICATION_NAME = "client_application_name";
	 public static final String CLIENT_SECURE_ID = "client_sec_id";
	 public static final String OPERATION_NAME = "Operation";
	 public static final String SAOP_ACTION = "soapAction";

}
