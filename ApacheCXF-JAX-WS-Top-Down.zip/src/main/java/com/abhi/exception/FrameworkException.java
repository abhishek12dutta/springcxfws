package com.abhi.exception;

public class FrameworkException extends RuntimeException implements ApplicationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final ApplicationError error;
	private transient boolean isLogged = false;

	@Override
	public String getErrorCode() {
		// TODO Auto-generated method stub
		return this.error.getErrorCode();
	}

	@Override
	public String getErrorDescription() {
		return this.error.getErrorDescription();
	}

	@Override
	public boolean isLogged() {
		return this.isLogged;
	}

	@Override
	public void setLogged() {
		this.isLogged = true;

	}

	public FrameworkException(ApplicationError error) {
		this.error = error;
	}

	public FrameworkException(ApplicationError error, String message) {
		super(message);
		this.error = error;
	}

	public FrameworkException(ApplicationError error, Throwable aCausingException) {
		super(aCausingException);
		this.error = error;
	}

	public FrameworkException(ApplicationError error, Throwable aCausingException, String message) {
		super(message, aCausingException);
		this.error = error;
	}

}
