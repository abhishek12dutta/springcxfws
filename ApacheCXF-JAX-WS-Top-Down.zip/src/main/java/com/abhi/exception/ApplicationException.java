package com.abhi.exception;

public interface ApplicationException {
	
	String getErrorCode();

    String getErrorDescription();

    boolean isLogged();

    void setLogged();

}
