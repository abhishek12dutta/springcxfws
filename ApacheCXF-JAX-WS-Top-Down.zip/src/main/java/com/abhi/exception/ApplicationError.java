package com.abhi.exception;

import java.io.Serializable;

public interface ApplicationError extends Serializable{

	String getErrorCode();

    String getErrorDescription();
    
}
