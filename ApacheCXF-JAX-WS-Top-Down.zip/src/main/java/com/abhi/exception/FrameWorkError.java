package com.abhi.exception;

public enum FrameWorkError implements ApplicationError {

	NO_CLIENT_NAME_FOUND("FRAM_GEN_A0001"),
	INVALID_URL("FRAM_GEN_A0002"),
	IF_MATCH_HEADER_MISSING("FRAM_GEN_A0003"),
	IP_CONVERSION_ERROR("FRAM_SECURITY_A0001"),
	INVALID_IP_ADDRESS("FRAM_SECURITY_A0002");

	private String code;

	private FrameWorkError(String code) {
		this.code = code;
	}

	public String getErrorCode() {
		return this.code;
	}

	public String getErrorDescription() {
		return this.name();
	}

}
