package com.abhi.listener;

import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.endpoint.Server;
import org.apache.cxf.endpoint.ServerLifeCycleListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abhi.interceptors.CommonHeadersInterceptor;
import com.abhi.interceptors.FrameWorkClientCallerInboundCXFInterceptor;
import com.abhi.interceptors.FrameWorkClientCallerOutboundCXFInterceptor;
import com.abhi.interceptors.FrameWorkLoggingInInterceptor;
import com.abhi.interceptors.FrameWorkLoggingOutInterceptor;
import com.abhi.interceptors.FrameworkSoapFaultInterceptor;
import com.abhi.interceptors.RequestValidatorInterceptor;

public class SoapServiceStartupListener implements ServerLifeCycleListener {
	private static final Logger LOGGER = LoggerFactory.getLogger(SoapServiceStartupListener.class);

	public void startServer(Server server) {
		LOGGER.info("started server");
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("registering default interceptors..");
		}
		Endpoint endpoint = server.getEndpoint();

		// add all in interceptors
		endpoint.getInInterceptors().add(new FrameWorkClientCallerInboundCXFInterceptor());
		endpoint.getInInterceptors().add(new FrameWorkLoggingInInterceptor());
		endpoint.getInInterceptors().add(new RequestValidatorInterceptor());
		
		

		// add all out interceptors
		endpoint.getOutInterceptors().add(new CommonHeadersInterceptor());
		endpoint.getOutInterceptors().add(new FrameWorkLoggingOutInterceptor());
		endpoint.getOutInterceptors().add(new FrameWorkClientCallerOutboundCXFInterceptor());
		
		//add fault
		
		endpoint.getOutFaultInterceptors().add(new FrameworkSoapFaultInterceptor());

	}

	public void stopServer(Server server) {
		LOGGER.info("stopping server");

	}

}
