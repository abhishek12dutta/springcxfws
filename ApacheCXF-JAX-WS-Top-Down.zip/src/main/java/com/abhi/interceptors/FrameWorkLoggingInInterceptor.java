package com.abhi.interceptors;

import java.net.MalformedURLException;
import java.net.URL;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingMessage;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abhi.exception.FrameWorkError;
import com.abhi.exception.FrameworkException;
import com.abhi.util.ServiceContextHolder;

/**
 * Override of the CXF LoggingInInterceptor to force the logging to be in the
 * format we require and to log the data specified in http://cap-wiki.uk.ba.com/twiki/bin/view/CAPTWO/SDServiceMetaData
 * <p/>
 * Note it is also possible to do fancy things like limit the amount of data logged - see
 * the superclass {@link LoggingInInterceptor}.
 * <p/>
 *
 * @author Mandy Warren
 */
public class FrameWorkLoggingInInterceptor extends LoggingInInterceptor {

    private static final Logger LOGGER = LoggerFactory.getLogger(FrameWorkLoggingInInterceptor.class);

    /**
     * Instantiates a new instance of this class
     */
    public FrameWorkLoggingInInterceptor() {
        super(Phase.RECEIVE);
        setPrettyLogging(false);
        getAfter().add(FrameWorkClientCallerInboundCXFInterceptor.class.getName());
    }

    /**
     * Instantiates a new instance of this class with the specified logging limit
     *
     * @param limit the limit
     */
    public FrameWorkLoggingInInterceptor(int limit) {
        super(limit);
        setPrettyLogging(false);
        getAfter().add(FrameWorkClientCallerInboundCXFInterceptor.class.getName());
    }

    @Override
    public void handleFault(Message message) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handling a fault");
        }
    }

    @Override
    public void log(java.util.logging.Logger notOurLogger, String message) {
        LOGGER.info(message);
    }

    @Override
    protected String formatLoggingMessage(LoggingMessage loggingMessage) {
        String payload = null;
        String address = null;
        String httpMethod = null;

        try {
            payload = loggingMessage.getPayload().toString();
            address = loggingMessage.getAddress().toString();

            // for http transport requests we need to determine the
            // url path excluding the host:port..
            String addressWithoutHostAndPort = address;
            if (address.contains("http://") || (address.contains("https://"))) {
                try {
                    URL url = new URL(address);
                    addressWithoutHostAndPort = url.getPath();
                } catch (MalformedURLException e) {
                    throw new FrameworkException(FrameWorkError.INVALID_URL, e);
                }
            } else {
                // we're using local transport or something else
                addressWithoutHostAndPort = address.substring(address.indexOf("://") + 3);
            }
            // store this for use later on..
            ServiceContextHolder.getContext().put("captwo.request.urlPath", addressWithoutHostAndPort);

            // determine the http method..
            httpMethod = loggingMessage.getHttpMethod().toString();
            // and store this for use later on..
            ServiceContextHolder.getContext().put("captwo.request.httpMethod", httpMethod);

        } catch (Throwable e) {
            throw new Fault(e);
        }

        return "TYPE+REQUEST|url=(" + httpMethod + ")"
                + address+"]"
                + "[payload=" + payload;
    }
}
