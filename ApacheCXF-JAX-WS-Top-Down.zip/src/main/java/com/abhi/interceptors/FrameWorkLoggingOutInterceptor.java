package com.abhi.interceptors;

import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingMessage;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Override of the CXF LoggingOutInterceptor to force the logging to be in the
 * format we require.
 * <p/>
 * Note it is also possible to do fancy things like limit the amount of data
 * logged - see the superclass {@link LoggingInInterceptor}.
 *
 */
public class FrameWorkLoggingOutInterceptor extends LoggingOutInterceptor {

	private static final Logger LOGGER = LoggerFactory.getLogger(FrameWorkLoggingOutInterceptor.class);

	/**
	 * Instantiates a new CAPTWO logging out interceptor.
	 *
	 * @param phase
	 *            the phase
	 */
	public FrameWorkLoggingOutInterceptor(String phase) {
		super(phase);
		setPrettyLogging(false);
	}

	/**
	 * Instantiates a new CAPTWO logging out interceptor.
	 */
	public FrameWorkLoggingOutInterceptor() {
		this(Phase.PRE_STREAM);
		setPrettyLogging(false);
	}

	@Override
	public void log(java.util.logging.Logger notOurLogger, String message) {

		LOGGER.info(message);
	}

	@Override
	protected String formatLoggingMessage(LoggingMessage loggingMessage) {
		String payload = loggingMessage.getPayload().toString();
		String responseCode = loggingMessage.getResponseCode().toString();

		String response = "TYPE+RESPONSE|responseCode=" + responseCode;

		if (LOGGER.isDebugEnabled()) {
			// *** log the response but mask any sensitive data ***
			response = response + "][payload=" + payload;
		}

		return response;
	}

}
