package com.abhi.interceptors;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Null;

import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abhi.util.ApplicationTransportHeader;
import com.abhi.util.IpAddress;
import com.abhi.util.ServiceContextHolder;
import com.abhi.util.TransactionUtils;

/**
 * Interceptor which interrogates the underlying message transport context to
 * extract various headers which the client has sent through as part of the web
 * service invocation, and stores them for later on processing.
 * <p/>
 * Note that the validation of headers is done later in the interceptor chain as
 * we want to ensure all requests (valid or otherwise) are logged.
 *
 */
public class FrameWorkClientCallerInboundCXFInterceptor extends AbstractPhaseInterceptor<Message> {

	private static final Logger LOGGER = LoggerFactory.getLogger(FrameWorkClientCallerInboundCXFInterceptor.class);
	private static final String DEFAULT_LOCALE = "en_GB";

	// based on https://docs.oracle.com/javase/7/docs/api/java/util/Locale.html
	// language & country definitions
	private static final Pattern LOCALE_PATTERN = Pattern.compile("locale=([a-zA-Z]{2,8}_([a-zA-Z]{2}|[0-9]{3}))");
	private static final String COMMA = ",";

	/**
	 * Constructs a new instance of this interceptor
	 */
	public FrameWorkClientCallerInboundCXFInterceptor() {
		super(Phase.RECEIVE);
	}

	private static final List<String> SENSITIVE_HEADERS = new ArrayList<>();

	static {

		// populate sensitive header that need to be masked
		SENSITIVE_HEADERS.add(ApplicationTransportHeader.CLIENT_SECURE_ID);

	}

	@Override
	public void handleMessage(Message message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("setting calling context for thread");
		}
		// clear out existing contexts just in case they weren't cleared before!
		clearCallingContext();

		// retrieve headers in a CaseInsensitiveMap *****NB this uses the key as
		// LOWERCASE********
		Map<String, String> rawHeaders = HttpHeaderExtractionUtil.getAllRequestHeaders(message);
		Map<String, String> printableRawHeaders = HttpHeaderExtractionUtil.getAllRequestHeaders(message);

		// logs the incoming request headers (masking the sensitive header's
		// values)
		for (String s : SENSITIVE_HEADERS) {
			if (printableRawHeaders.containsKey(s)) {
				printableRawHeaders.put(s, "****");
			}
		}
		LOGGER.info("Incoming request headers : " + printableRawHeaders.entrySet());

		String uniqueTxId = TransactionUtils.generateUniqueTransactionId();

		// put the uniqueTxid in holder

		ServiceContextHolder.getContext().put(ApplicationTransportHeader.UNIQUE_TRANSACTION_ID, uniqueTxId);

		String clientIP = null;

		// LOGGER.warn("true-client-ip header not set, defaulting to remote
		// address");
		HttpServletRequest locale = (HttpServletRequest) message.get("HTTP.REQUEST");
		if (null != locale) {
			clientIP = locale.getRemoteAddr();
		}

		if (null != clientIP && !(new IpAddress(clientIP)).isInvalid()) {
			ServiceContextHolder.getContext().put(ApplicationTransportHeader.REMOTE_CLIENT_IP_ADDRESS, clientIP);
		} else {
			LOGGER.warn("client-ip header not set, defaulting to remote address");
		}
		
		 String soapAction = (String)rawHeaders.get("soapAction");
		
		ServiceContextHolder.getContext().put(ApplicationTransportHeader.SAOP_ACTION, soapAction);

	}

	/**
	 * Retrieves the locale from the URI.
	 *
	 * @param uri
	 *            the uri of the REST call
	 * @return the locale used for this webservice call
	 */
	@Null
	private static String getLocaleFromURI(String uri) {
		Matcher m = LOCALE_PATTERN.matcher(uri);
		return m.find() ? m.group(1) : DEFAULT_LOCALE;
	}

	@Override
	public void handleFault(Message message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handling a fault");
			// DO NOT CLEAR THE CONTEXT HERE!
			// SEE Jira - http://jira.baplc.com/jira/browse/CAPTWOFW-474
		}
	}

	private static void clearCallingContext() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("clearing calling contexts");
		}
		// and the ServiceContext..
		ServiceContextHolder.clearContext();
	}
}