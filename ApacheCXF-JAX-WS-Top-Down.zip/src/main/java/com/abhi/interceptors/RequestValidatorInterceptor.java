package com.abhi.interceptors;

import java.util.Map;

import org.apache.commons.collections4.map.CaseInsensitiveMap;
import org.apache.cxf.jaxrs.interceptor.JAXRSInInterceptor;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abhi.exception.FrameWorkError;
import com.abhi.exception.FrameworkException;
import com.abhi.util.ApplicationTransportHeader;

public class RequestValidatorInterceptor extends AbstractPhaseInterceptor<Message> {


	private static final Logger LOGGER = LoggerFactory.getLogger(RequestValidatorInterceptor.class);

	/**
	 * Instantiates a new CAPTWO request validator interceptor.
	 */
	public RequestValidatorInterceptor() {
		super(Phase.UNMARSHAL);
		getAfter().add(JAXRSInInterceptor.class.getName());
	}

	@Override
	public void handleMessage(Message message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("checking for mandatory headers");
		}

		Map<String, String> transportHeaders = HttpHeaderExtractionUtil.getAllRequestHeaders(message);

		CaseInsensitiveMap caseInsensitiveMap = new CaseInsensitiveMap(transportHeaders);

		if (!caseInsensitiveMap.containsKey(ApplicationTransportHeader.CLIENT_APPLICATION_NAME)) {
			throw new FrameworkException(FrameWorkError.NO_CLIENT_NAME_FOUND);
		}
	}
}
