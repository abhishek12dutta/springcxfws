package com.abhi.interceptors;

import java.io.ByteArrayInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import com.abhi.exception.FrameworkException;

public class FrameworkSoapFaultInterceptor extends AbstractSoapInterceptor {

	private static final Logger LOGGER = LoggerFactory.getLogger(FrameworkSoapFaultInterceptor.class);

	/**
	 * Sole constructor
	 */
	public FrameworkSoapFaultInterceptor() {
		super(Phase.PREPARE_SEND);
		// The CAPTWOSoapFaultInterceptor interceptor needs to run before the
		// CAPTWOCommonHeadersInterceptor
		getBefore().add(CommonHeadersInterceptor.class.getName());
	}

	@Override
	public void handleMessage(SoapMessage message) throws Fault {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handling a soap fault");
		}

		// Get details of the underlying fault
		Exception e = message.getContent(Exception.class);
		if (e instanceof Fault) {
			Fault fault = (Fault) e;
			Throwable cause = e.getCause();

			// TODO - make this a field?
			String errorDetail = null;

			// If the SOAP fault is caused by the client not passing mandatory
			// headers when calling CAPTWO
			if (cause instanceof FrameworkException) {
				errorDetail = processFrameworkException(cause, fault);
			}

			try (ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(errorDetail.getBytes())) {
				DocumentBuilder builder = getBuilder();
				Document doc = builder.parse(byteArrayInputStream);
				fault.setDetail(doc.getDocumentElement());
			} catch (Exception e1) {
				LOGGER.error("Cannot build fault detail element: " + e1.getMessage());
				// not a lot we can do here as if we throw an exception I am not
				// sure what will happen?!
			}
		}

	}

	private String processFrameworkException(Throwable cause, Fault fault) {
		String errorDetail;
		errorDetail = getErrorDetail("FRAM_B0006");
		return errorDetail;
	}

	private String getErrorDetail(String errorCode) {
		return "<detail><code>" + errorCode + "</code></detail>";
	}

	private DocumentBuilder getBuilder() throws ParserConfigurationException {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		return dbf.newDocumentBuilder();
	}

}
