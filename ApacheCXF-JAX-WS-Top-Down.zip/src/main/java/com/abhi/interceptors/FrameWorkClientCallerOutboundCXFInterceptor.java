package com.abhi.interceptors;

import org.apache.cxf.interceptor.MessageSenderInterceptor.MessageSenderEndingInterceptor;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Clears the client calling context to ensure no memory leaks.
 *
 */
public class FrameWorkClientCallerOutboundCXFInterceptor extends AbstractPhaseInterceptor<Message> {

	private static final Logger LOGGER = LoggerFactory.getLogger(FrameWorkClientCallerOutboundCXFInterceptor.class);

	/**
	 * Instantiates a new CAPTWO client caller outbound cXF interceptor.
	 */
	public FrameWorkClientCallerOutboundCXFInterceptor() {
		super(Phase.PREPARE_SEND_ENDING);
		getAfter().add(MessageSenderEndingInterceptor.class.getName());
	}

	@Override
	public void handleMessage(Message message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("clearing calling context for thread");
		}
	}

	@Override
	public void handleFault(Message message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handling a fault");
		}
	}

}
