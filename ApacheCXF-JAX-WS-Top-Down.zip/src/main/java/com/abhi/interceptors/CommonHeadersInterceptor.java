package com.abhi.interceptors;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abhi.util.ApplicationTransportHeader;
import com.abhi.util.ServiceContextHolder;

/**
 * Returns key headers and any error codes to allow a client to track the status
 * of a transaction through the system
 *
 */
public class CommonHeadersInterceptor extends AbstractPhaseInterceptor<Message> {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonHeadersInterceptor.class);


	/**
	 * Instantiates a new CAPTWO common headers interceptor.
	 */
	public CommonHeadersInterceptor() {
		super(Phase.PREPARE_SEND);
	}

	@Override
	public void handleMessage(Message message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("setting return headers");
		}
		Map<String, List<String>> headers = (Map<String, List<String>>) message.get(Message.PROTOCOL_HEADERS);

		if (null == headers) {
			headers = new HashMap<>();
			message.put(Message.PROTOCOL_HEADERS, headers);
		}
		
		Map<String, Object> holder = ServiceContextHolder.getContext();
		((Map)headers).put(ApplicationTransportHeader.UNIQUE_TRANSACTION_ID, Collections.singletonList(holder.get(ApplicationTransportHeader.UNIQUE_TRANSACTION_ID)));
		((Map)headers).put(ApplicationTransportHeader.CLIENT_SESSIONID, Collections.singletonList(holder.get(ApplicationTransportHeader.CLIENT_SESSIONID)));
		
		String operation = (String)holder.get(ApplicationTransportHeader.OPERATION_NAME);
		
        if(null != operation && !"".equals(operation)) {
            ((Map)headers).put("Operation", Collections.singletonList(operation));
        }
		message.put(Message.PROTOCOL_HEADERS, headers);
	}

}
