package com.abhi.interceptors;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.CaseInsensitiveMap;
import org.apache.cxf.message.Message;

import com.google.common.base.Function;
import com.google.common.collect.Maps;

public final class HttpHeaderExtractionUtil {

	private HttpHeaderExtractionUtil() {

	}

	/**
	 * Gets specific request headers.
	 *
	 * @param headerNames
	 *            the header names
	 * @param message
	 *            the message
	 * @return the specific request headers
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, String> getSpecificRequestHeaders(Enum[] headerNames, Message message) {
		Map<String, List<String>> headers = (Map<String, List<String>>) message.get(Message.PROTOCOL_HEADERS);
		return extractRelevantHeaders(headerNames, headers);
	}

	/**
	 * Gets all request headers.
	 *
	 * @param message
	 *            the message
	 * @return the all request headers
	 */
	public static Map<String, String> getAllRequestHeaders(Message message) {
		Map<String, List<String>> headers = (Map<String, List<String>>) message.get(Message.PROTOCOL_HEADERS);
		return extractAllHeaders(headers);
	}

	/**
	 * Given a list of headers to find, this method will perform a case
	 * insensitive lookup (i.e. doesn't matter if case differs) of the value in
	 * the http request.
	 * <p/>
	 * So for example if you request a header of "MyHeader" and the http request
	 * contains the header "myheader", this will match and be returned.
	 *
	 * @param headerNames
	 *            List of case insensitive header names to match on
	 * @param messageHeaders
	 *            the message headers to extract the headers from
	 * @return a Map of header to value mappings, where the key is the original
	 *         name of the header as requested in headerNames and the value is
	 *         the associated value as found in the httpServlet request
	 */
	private static Map<String, String> extractRelevantHeaders(Enum[] headerNames,
			Map<String, List<String>> messageHeaders) {
		if (messageHeaders != null) {
			Map<String, String> translationLookup = getTranslationLookup(headerNames);
			Map<String, String> headers = Maps.transformValues(messageHeaders, GET_FIRST_VALUE);
			Map<String, String> translatedHeaders = new CaseInsensitiveMap<>();

			for (Map.Entry<String, String> headerEntry : headers.entrySet()) {
				String actualKey = headerEntry.getKey();
				String value = headerEntry.getValue();

				String translatedKey = translationLookup.get(actualKey.toUpperCase());

				if (null != translatedKey && null != value) {
					translatedHeaders.put(translatedKey, value);
				}
			}
			return translatedHeaders;
		} else {
			return new CaseInsensitiveMap<>(1);
		}
	}

	/**
	 * Extracts all the http message headers into a simpler map
	 *
	 * @param messageHeaders
	 *            the http message headers
	 * @return a simple map
	 */
	private static Map<String, String> extractAllHeaders(Map<String, List<String>> messageHeaders) {
		// Gets the first value
		return messageHeaders != null ? new CaseInsensitiveMap<>(Maps.transformValues(messageHeaders, GET_FIRST_VALUE))
				: new CaseInsensitiveMap<String, String>(1);
	}

	private static Map<String, String> getTranslationLookup(Enum[] headerNames) {
		Map<String, String> translationLookup = new HashMap<>();
		for (Enum headerName : headerNames) {
			translationLookup.put(headerName.toString().toUpperCase(), headerName.toString());
		}
		return translationLookup;
	}

	private static final Function<List<String>, String> GET_FIRST_VALUE = new Function<List<String>, String>() {
		@Override
		public String apply(List<String> strings) {
			return strings == null || strings.isEmpty() ? null : strings.get(0);
		}
	};
}
