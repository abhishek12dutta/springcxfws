package org.exampledriven.zuul.filter.post;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.exampledriven.zuul.core.properties.InboundWhitelistProperties;
import org.exampledriven.zuul.filter.utils.FilterType;
import org.exampledriven.zuul.filter.utils.FilterUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

/**
 * Created by Peter_Szanto on 6/14/2016.
 */
@Component
public class AccessLogFilter extends ZuulFilter {
	
	//define this once per filter to avoid mismatches
    private static final FilterType FILTER_TYPE = FilterType.POST;
    
	
	@Autowired
    private InboundWhitelistProperties inboundWhitelistProperties;

	private static final Logger logger = LoggerFactory.getLogger(AccessLogFilter.class);

	@Override
	public String filterType() {
		return FILTER_TYPE.getName();
	}

	@Override
	public int filterOrder() {
		return FilterUtils.getFilterOrder(getClass(), FILTER_TYPE);
	}

	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public Object run() {
		HttpServletRequest request = RequestContext.getCurrentContext().getRequest();
		HttpServletResponse response = RequestContext.getCurrentContext().getResponse();

		logger.info("RESPONSE:: > HEADERS:" + inboundWhitelistProperties.getHeaders());
		
		logger.info(
				"REQUEST :: < " + request.getScheme() + " " + request.getLocalAddr() + ":" + request.getLocalPort());
		logger.info(
				"REQUEST :: < " + request.getMethod() + " " + request.getRequestURI() + " " + request.getProtocol());
		logger.info("RESPONSE:: > HTTP:" + response.getStatus());

		return null;
	}
}
