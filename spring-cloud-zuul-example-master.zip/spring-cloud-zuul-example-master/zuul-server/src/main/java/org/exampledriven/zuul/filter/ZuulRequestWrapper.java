package org.exampledriven.zuul.filter;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;

import org.exampledriven.zuul.core.properties.InboundWhitelistProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.netflix.zuul.http.HttpServletRequestWrapper;

public class ZuulRequestWrapper extends HttpServletRequestWrapper {

	private static final Logger LOGGER = LoggerFactory.getLogger(ZuulRequestWrapper.class);

	private final InboundWhitelistProperties inboundWhitelistProperties;
	private final HttpServletRequest request;

	public ZuulRequestWrapper(HttpServletRequest request, InboundWhitelistProperties inboundWhitelistProperties) {
		super(request);
		this.inboundWhitelistProperties = inboundWhitelistProperties;
		this.request = request;
	}

	@Override
	public Enumeration<String> getHeaderNames() {
		
		String requestURI = request.getRequestURI();
		
		LOGGER.info("invoking ZuulRequestWrapper with uri: " + requestURI);

		List<String> allowedHeaders;
		// Get all the headers which appear in the request
		Enumeration<String> e = super.getHeaderNames();
		final List<String> filteredHeaders = new ArrayList<>();
		// Get all the allowed headers
		allowedHeaders = inboundWhitelistProperties.getHeaders();

		Set<String> allowedSet = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
		allowedSet.addAll(allowedHeaders);

		// Check each actual header in the request. If it is one of our
		// "allowed" headers, add it to the filteredHEaders (i.e. the ones we
		// are keeping)
		while (e.hasMoreElements()) {
			String header = e.nextElement();
			if (allowedSet.contains(header)) {
				filteredHeaders.add(header);
			}
		}

		return new Enumeration<String>() {
			private final String[] arr = filteredHeaders.toArray(new String[0]);
			private int idx;

			@Override
			public boolean hasMoreElements() {
				return idx < arr.length;
			}

			@Override
			public String nextElement() {
				return arr[idx++];
			}
		};
	}

}
