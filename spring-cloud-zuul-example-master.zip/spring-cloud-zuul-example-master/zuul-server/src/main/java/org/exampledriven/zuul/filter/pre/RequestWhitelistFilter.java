package org.exampledriven.zuul.filter.pre;

import static com.netflix.zuul.context.RequestContext.getCurrentContext;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.exampledriven.zuul.core.properties.InboundWhitelistProperties;
import org.exampledriven.zuul.filter.ZuulRequestWrapper;
import org.exampledriven.zuul.filter.utils.FilterType;
import org.exampledriven.zuul.filter.utils.FilterUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

@Component
public class RequestWhitelistFilter extends ZuulFilter {

	private static final Logger LOGGER = LoggerFactory.getLogger(RequestWhitelistFilter.class);

	@Autowired
	private InboundWhitelistProperties inboundWhitelistProperties;

	private static final FilterType FILTER_TYPE = FilterType.PRE;

	@Override
	public Object run() {
		final RequestContext ctx = getCurrentContext();
		final HttpServletRequest request = ctx.getRequest();

		ZuulRequestWrapper zuulRequestWrapper = new ZuulRequestWrapper(request, inboundWhitelistProperties);
		ctx.setRequest(zuulRequestWrapper);

		return null;
	}

	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public int filterOrder() {
		return FilterUtils.getFilterOrder(getClass(), FILTER_TYPE);
	}

	@Override
	public String filterType() {
		return FILTER_TYPE.getName();
	}

	/**
	 * Log the whitelist headers once on startup for support purposes
	 */
	@PostConstruct
	public void init() {
		StringBuilder stringBuilder = new StringBuilder("[Inbound whitelist : ");

		List<String> inboundWhitelistPropertiesHeaders = inboundWhitelistProperties.getHeaders();
		int inboundHeadersSize = inboundWhitelistPropertiesHeaders.size();
		int counter = 0;
		for (String header : inboundWhitelistPropertiesHeaders) {
			counter++;
			stringBuilder.append(header);
			if (counter < inboundHeadersSize) {
				stringBuilder.append(", ");
			}
		}

		stringBuilder.append("]");
		stringBuilder.append("\n");

		LOGGER.info(stringBuilder.toString());
	}

}
