package org.exampledriven.zuul.core.properties;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix = "inbound")
@Component
public class InboundWhitelistProperties {
	
	 private final List<String> headers = new ArrayList<>();

	    /**
	     * Gets headers.
	     *
	     * @return the headers
	     */
	    public List<String> getHeaders() {
	        return headers;
	    }

}
