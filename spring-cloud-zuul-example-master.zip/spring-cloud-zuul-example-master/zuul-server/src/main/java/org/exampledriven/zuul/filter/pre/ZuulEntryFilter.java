package org.exampledriven.zuul.filter.pre;

import static com.netflix.zuul.context.RequestContext.getCurrentContext;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;

import org.exampledriven.zuul.filter.utils.FilterType;
import org.exampledriven.zuul.filter.utils.FilterUtils;
import org.exampledriven.zuul.filter.utils.TransactionIdManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

/**
 * Adds a line to the logs when an inbound request enters zuul from a client
 *
 * @author Sam Cross u188166
 */
@Component
public class ZuulEntryFilter extends ZuulFilter {

	// define this once per filter to avoid mismatches
	private static final FilterType FILTER_TYPE = FilterType.PRE;

	private static final Logger LOGGER = LoggerFactory.getLogger(ZuulEntryFilter.class);

	@Override
	public String filterType() {
		return FILTER_TYPE.getName();
	}

	@Override
	public int filterOrder() {
		return FilterUtils.getFilterOrder(getClass(), FILTER_TYPE);
	}

	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public Object run() {

		final RequestContext ctx = getCurrentContext();
		final HttpServletRequest request = ctx.getRequest();

		ctx.put("entry.time", LocalDateTime.now());

		StringBuilder stringBuilder = new StringBuilder(100);
		stringBuilder.append("TYPE+ZUULENTRY | url:(").append(request.getMethod()).append(")")
				.append(request.getRequestURL());

		appendRequestPayload(stringBuilder);

		TransactionIdManager.setCapTwoTxId();

		// This ensures any call into zuul (i.e. the first time into zuul for a
		// particular thread; from a client) will pass a txId
		ctx.addZuulRequestHeader("service_tx_id", TransactionIdManager.getCapTwoTxId());

		LOGGER.info(stringBuilder.toString());

		return null;
	}

	/**
	 * Append request payload to the stringbuilder (used in debug in the entry
	 * filters)
	 *
	 * @param stringBuilder
	 *            the string builder
	 */
	private static void appendRequestPayload(StringBuilder stringBuilder) {
		RequestContext ctx = getCurrentContext();
		HttpServletRequest request = ctx.getRequest();
		InputStream in = (InputStream) ctx.get("requestEntity");
		String requestBody = "";
		try {
			if (in == null) {
				in = request.getInputStream();
			}
			requestBody = StreamUtils.copyToString(in, Charset.forName("UTF-8"));
		} catch (IOException e) {
			// only in debug so don't want to fail
			LOGGER.warn("Error reading request payload");
		}

		if (!requestBody.isEmpty()) {
			stringBuilder.append(" | payload:");
			stringBuilder.append(requestBody);
		}
	}

}
