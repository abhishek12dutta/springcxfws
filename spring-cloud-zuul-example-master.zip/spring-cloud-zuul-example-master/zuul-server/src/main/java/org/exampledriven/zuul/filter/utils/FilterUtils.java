package org.exampledriven.zuul.filter.utils;

import java.util.HashMap;
import java.util.Map;

import org.exampledriven.zuul.core.errors.ZuulError;
import org.exampledriven.zuul.core.exceptions.ZuulException;
import org.exampledriven.zuul.filter.post.AccessLogFilter;
import org.exampledriven.zuul.filter.post.AddResponseHeaderFilter;
import org.exampledriven.zuul.filter.post.ZuulExitFilter;
import org.exampledriven.zuul.filter.pre.RequestWhitelistFilter;
import org.exampledriven.zuul.filter.pre.ZuulEntryFilter;

import com.netflix.zuul.ZuulFilter;

public class FilterUtils {

	
	private FilterUtils() {
	}

	private static final Map<FilterType, Map<Class<? extends ZuulFilter>, Integer>> FILTER_TYPE_MAP;
	
	
	 static {
	        FILTER_TYPE_MAP = new HashMap<>();
	        setPreFilterOrders();
	        setPostFilterOrders();
	       /* setRouteFilterOrders();
	        setErrorFilterOrders();*/
	    }


	private static void setPreFilterOrders() {
		
		Map<Class<? extends ZuulFilter>, Integer> map = new HashMap<>();
        map.put(RequestWhitelistFilter.class, 1);
        map.put(ZuulEntryFilter.class, 2);
        FILTER_TYPE_MAP.put(FilterType.PRE, map);
		
	}
	
	
	private static void setPostFilterOrders() {
		Map<Class<? extends ZuulFilter>, Integer> map = new HashMap<>();
        map.put(AccessLogFilter.class, 1);
        map.put(AddResponseHeaderFilter.class, 2);
        map.put(ZuulExitFilter.class, 3);
        
        FILTER_TYPE_MAP.put(FilterType.POST, map);
		
	}


	/**
     * Gets filter order for a given filter and type
     *
     * @param klass      the klass
     * @param filterType the filter type
     * @return the filter order
     */
    public static int getFilterOrder(Class<? extends ZuulFilter> klass, FilterType filterType) {

        Map<Class<? extends ZuulFilter>, Integer> filterOrderForType = FILTER_TYPE_MAP.get(filterType);
        Integer filterOrder = filterOrderForType.get(klass);

        if (filterOrder != null) {
            return filterOrder;
        } else {
            throw new ZuulException(ZuulError.NO_FILTER_ORDER_CONFIGURED, klass.getSimpleName() + " has not been configured with an order - please add an entry in " +
                    "FilterUtils");
        }
    }
	
	
	

}
