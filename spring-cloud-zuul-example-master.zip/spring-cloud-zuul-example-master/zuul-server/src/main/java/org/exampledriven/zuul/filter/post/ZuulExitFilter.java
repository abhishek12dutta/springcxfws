package org.exampledriven.zuul.filter.post;

import static com.netflix.zuul.context.RequestContext.getCurrentContext;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.Duration;
import java.time.LocalDateTime;

import javax.servlet.http.HttpServletResponse;

import org.exampledriven.zuul.filter.utils.FilterType;
import org.exampledriven.zuul.filter.utils.FilterUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.google.common.io.CharStreams;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

/**
 * Adds a line to the logs when an inbound request from a client has completed
 *
 */
@Component
public class ZuulExitFilter extends ZuulFilter {

	// define this once per filter to avoid mismatches
	private static final FilterType FILTER_TYPE = FilterType.POST;

	private static final Logger LOGGER = LoggerFactory.getLogger(ZuulExitFilter.class);

	@Override
	public String filterType() {
		return FILTER_TYPE.getName();
	}

	@Override
	public int filterOrder() {
		return FilterUtils.getFilterOrder(getClass(), FILTER_TYPE);
	}

	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public Object run() {
		RequestContext ctx = getCurrentContext();
		HttpServletResponse response = ctx.getResponse();

		StringBuilder stringBuilder = new StringBuilder(100);
		stringBuilder.append("TYPE+ZUULEXIT | status:").append(response.getStatus());

		appendResponsePayload(stringBuilder);

		appendTimeForReq(stringBuilder);

		LOGGER.info(stringBuilder.toString());

		return null;
	}

	/**
	 * Append response payload to the stringbuilder (used in debug in the exit
	 * filters)
	 *
	 * @param stringBuilder
	 *            the string builder
	 */
	private static void appendResponsePayload(StringBuilder stringBuilder) {
		String responseBody = "";
		RequestContext ctx = getCurrentContext();
		try (final InputStream responseDataStream = ctx.getResponseDataStream()) {
			if (null != responseDataStream) {
				responseBody = CharStreams.toString(new InputStreamReader(responseDataStream, "UTF-8"));
			} else {
				LOGGER.warn("Error reading response payload - responseDataStream is null");
			}
		} catch (IOException e) {
			// only in debug so don't want to fail
			LOGGER.warn("Error reading response payload", e);
		}

		if (!responseBody.isEmpty()) {
			ctx.setResponseBody(responseBody);
			stringBuilder.append(" | payload:");
			stringBuilder.append(responseBody);
		}
	}

	/**
	 * Append time for req to StringBuilder
	 *
	 * @param stringBuilder
	 *            the string builder
	 */
	private static void appendTimeForReq(StringBuilder stringBuilder) {
		LocalDateTime entryTime = (LocalDateTime) getCurrentContext().get("entry.time");
		if (null != entryTime) {
			LocalDateTime exitTime = LocalDateTime.now();
			Duration dur = Duration.between(entryTime, exitTime);
			long timeForReq = dur.toMillis();
			stringBuilder.append(" | ms:");
			stringBuilder.append(timeForReq);
		}
	}
}
