package org.exampledriven.zuul.core.exceptions;

import org.exampledriven.zuul.core.errors.ZuulError;

/**
 * This is a runtime exception used in cases where we find non-recoverable errors (such as missing configuration data)
 *
 * @author Sam Cross u188166
 */
public class ZuulException extends RuntimeException {

    private final ZuulError zuulError;
    private String additionalInfo;

    /**
     * Instantiates a new Zuul exception.
     *
     * @param zuulError the zuul error
     */
    public ZuulException(ZuulError zuulError) {
        super(zuulError.getErrorMessage());
        this.zuulError = zuulError;
    }

    /**
     * Instantiates a new Zuul exception.
     *
     * @param zuulError the zuul error
     * @param message   the message
     */
    public ZuulException(ZuulError zuulError, String message) {
        super(zuulError.getErrorMessage() + " | " + message);
        this.zuulError = zuulError;
        this.additionalInfo = message;
    }

    /**
     * Instantiates a new Zuul exception.
     *
     * @param zuulError the zuul error
     * @param throwable the throwable
     */
    public ZuulException(ZuulError zuulError, Throwable throwable) {
        super(zuulError.getErrorMessage(), throwable);
        this.zuulError = zuulError;
    }

    /**
     * Instantiates a new Zuul exception.
     *
     * @param zuulError the zuul error
     * @param message   the message
     * @param throwable the throwable
     */
    public ZuulException(ZuulError zuulError, String message, Throwable throwable) {
        super(zuulError.getErrorMessage() + " | " + message, throwable);
        this.zuulError = zuulError;
        this.additionalInfo = message;
    }

    /**
     * Gets zuul error code.
     *
     * @return the zuul error code
     */
    public String getZuulErrorCode() {
        return zuulError.getErrorCode();
    }

    /**
     * Gets zuul error message.
     *
     * @return the zuul error message
     */
    public String getZuulErrorMessage() {
        return zuulError.getErrorMessage();
    }

    /**
     * Gets zuul error
     *
     * @return the zuul error
     */
    public ZuulError getZuulError() {
        return zuulError;
    }

    /**
     * Gets additional info.
     *
     * @return the additional info
     */
    public String getAdditionalInfo() {
        return additionalInfo;
    }
}
