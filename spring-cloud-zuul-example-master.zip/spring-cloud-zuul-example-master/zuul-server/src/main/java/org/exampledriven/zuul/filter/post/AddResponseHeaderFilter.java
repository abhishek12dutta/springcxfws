package org.exampledriven.zuul.filter.post;

import javax.servlet.http.HttpServletResponse;

import org.exampledriven.zuul.filter.utils.FilterType;
import org.exampledriven.zuul.filter.utils.FilterUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

@Component
public class AddResponseHeaderFilter extends ZuulFilter {
	
	 private static final FilterType FILTER_TYPE = FilterType.POST;
	
	Logger logger = LoggerFactory.getLogger(AddResponseHeaderFilter.class);
	
	
	public String filterType() {
		return FILTER_TYPE.getName();
	}

	public int filterOrder() {
		return FilterUtils.getFilterOrder(getClass(), FILTER_TYPE);
	}

	public boolean shouldFilter() {
		return true;
	}

	public Object run() {
		RequestContext context = RequestContext.getCurrentContext();
		HttpServletResponse servletResponse = context.getResponse();
		
		String header = context.getZuulRequestHeaders().get("service_tx_id");
		
		servletResponse.addHeader("service_tx_id", header);
		logger.info(
				"ADDED Response Header :: < " +header);
		return null;
	}
}
