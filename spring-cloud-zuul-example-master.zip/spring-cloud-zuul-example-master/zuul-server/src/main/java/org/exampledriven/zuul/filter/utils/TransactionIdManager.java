package org.exampledriven.zuul.filter.utils;

import static com.netflix.zuul.context.RequestContext.getCurrentContext;

import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

public final class TransactionIdManager {

	private static final String SERVICE_TX_ID = "service_tx_id";
	
	private static final Pattern ENV_PATTERN = Pattern.compile("zuul\\.(.*?)\\..*");
	

	private TransactionIdManager() {
	}
	
	
	public static void setCapTwoTxId() {
        String serviceTxId = HeaderUtils.getRequestHeader(SERVICE_TX_ID);

        if (serviceTxId == null) {
            serviceTxId = generateUniqueTransactionId();
        }
        // we need to store it on the RequestContext as it might be
        // removed from HTTP header by third-party providers etc.
        getCurrentContext().set(SERVICE_TX_ID, serviceTxId);
    }
	
    /**
     * Generates a globally unique transaction id
     *
     * @return String a unique transaction id
     */
    private static String generateUniqueTransactionId() {
        return "tx" + "-" + getEnvironment() + "-" + getUniqueTimeStamp();
    }

    /**
     * Generates a unique timestamp
     *
     * @return String a unique timestamp
     */
    @NotNull
    private static synchronized String getUniqueTimeStamp() {
        return UUID.randomUUID().toString();
    }

    /**
     * Gets the current captwoTxId
     *
     * @return the unique captwoTxId
     */
    @Null
    public static String getCapTwoTxId() {
        return (String) getCurrentContext().get(SERVICE_TX_ID);
    }
    
    
    

    

    @NotNull
    private static String getServerName() {
        String server = System.getProperty("zuul.Name");
        if (null == server) {
            server = "";
        }
        return server;
    }

    /**
     * Gets environment e.g. reg-03 or prod
     *
     * @return the environment
     */
    @NotNull
    public static String getEnvironment() {
        String server = getServerName();
        Matcher matcher = ENV_PATTERN.matcher(server);
        return matcher.matches() ? matcher.group(1) : "";
    }

}
