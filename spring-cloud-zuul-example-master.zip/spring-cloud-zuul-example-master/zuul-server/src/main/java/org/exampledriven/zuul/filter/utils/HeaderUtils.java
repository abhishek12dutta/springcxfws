package org.exampledriven.zuul.filter.utils;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;

import static com.netflix.zuul.context.RequestContext.getCurrentContext;

/**
 * Class to provide utils to deal with headers
 *
 */
public final class HeaderUtils {

    private HeaderUtils() {
    }

    /**
     * Get request header string.  Checks the whitelist first
     *
     * @param headerName the header name
     * @return the string
     */
    public static String getRequestHeader(String headerName){
        return isHeaderInRequest(headerName) ? getCurrentContext().getRequest().getHeader(headerName) : null;
    }

    /**
     * Check whether the header is in the request.  If it is, that means it must also be in the whitelist since
     * the getHeaderNames method has been overridden to apply this whitelist check
     *
     * @param headerName the header name
     * @return true if the header is in the request, otherwise false
     */
    public static boolean isHeaderInRequest(String headerName) {
        HttpServletRequest request = getCurrentContext().getRequest();
        Enumeration<String> headerNames = request.getHeaderNames();

        while (headerNames.hasMoreElements()) {
            String allowedHeaderName = headerNames.nextElement();
            if (headerName.equalsIgnoreCase(allowedHeaderName)) {
                return true;
            }
        }
        return false;
    }
}