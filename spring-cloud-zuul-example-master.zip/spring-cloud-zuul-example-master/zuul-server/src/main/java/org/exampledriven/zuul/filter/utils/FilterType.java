package org.exampledriven.zuul.filter.utils;

/**
 * Holds constants for the four different zuul filter types
 *
 * @author Sam Cross u188166
 */
public enum FilterType {

    PRE("pre"),
    ROUTE("route"),
    POST("post"),
    ERROR("error");

    // Enum implementation
    private final String name;

    /**
     * Constructs an instance with the specified detail
     *
     * @param name the filter type name
     */
    FilterType(String name) {
        this.name = name;
    }

    /**
     * Returns code from constructor input
     *
     * @return code
     */
    public String getName() {
        return name;
    }
}
