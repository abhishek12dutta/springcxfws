package org.exampledriven.zuul.core.errors;

/**
 * Defines the set of error codes used throughout the CAPTWO zuul code
 *
 * @author Sam Cross u188166
 */
public enum ZuulError {

    /**
     * No filter order configured zuul error.
     */
    NO_FILTER_ORDER_CONFIGURED("ZUUL_0001"),
    NO_SECURITY_SETTINGS_CONFIGURED("ZUUL_0002"),
    ERROR_ADDING_CREDENTIALS("ZUUL_0003"),
    INVALID_CREDENTIALS("ZUUL_0004"),
    NO_ROUTE_FOUND_FOR_URI("ZUUL_0005"),
    INVALID_ZUUL_CREDENTIALS("ZUUL_0006"),
    EMPTY_CREDSTASH_CREDENTIALS("ZUUL_0007");

    // Enum implementation
    private final String errorCode;

    /**
     * Constructs an instance with the specified detail
     *
     * @param errorCode the error code
     */
    ZuulError(String errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * Gets error message.
     *
     * @return the error message
     */
    public String getErrorMessage() {
        return name();
    }

    /**
     * Gets error code.
     *
     * @return the error code
     */
    public String getErrorCode() {
        return errorCode;
    }
}
