package org.exampledriven.zuul.eureka.customer.shared.server.server.rest;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.exampledriven.zuul.eureka.customer.shared.server.server.Application;
import org.exampledriven.zuul.eureka.customer.shared.server.server.domain.Customer;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {

	private static Logger logger = LogManager.getLogger(Application.class);

	private List<Customer> customers;

	public CustomerController() {
		customers = new LinkedList<>();
		customers.add(new Customer(1, "Peter", "Test"));
		customers.add(new Customer(2, "Roger", "Test2"));
	}
	
	
	@RequestMapping(value = "/viewAllCustomer", method = RequestMethod.GET, produces = "application/json")
	public List<Customer> viewAllCustomer() {

		logger.info("Inside getCustomer()");
		logger.info("Existing getCustomer()");

		return customers;

	}

	@RequestMapping(value = "/customerbyId/{id}", method = RequestMethod.GET, produces = "application/json")
	public Customer getCustomer(@PathVariable int id) {

		logger.info("Inside getCustomer()");

		Optional<Customer> customer = customers.stream().filter(customer1 -> customer1.getId() == id).findFirst();

		logger.info("Existing getCustomer()");

		return customer.get();

	}

	@RequestMapping(value = "/customerbyName/{firstname}", method = RequestMethod.GET, produces = "application/json")
	public Customer getCustomerByFirstName(@PathVariable String firstname) {
		logger.info("Inside getCustomerByFirstName()");
		Optional<Customer> customer = customers.stream()
				.filter(customer1 -> customer1.getFirstName().equalsIgnoreCase(firstname)).findFirst();
		logger.info("Existing getCustomerByFirstName()");
		return customer.get();

	}
	
	@RequestMapping(value = "/customer/addCustomer", method = RequestMethod.POST, consumes="application/json")
	public void addCustomer(@RequestBody Customer customer) {
		logger.info("Inside addCustomer()");
		
		boolean customerExists = false;
		
		for(Customer customer2 : customers){
			
			if(customer.getId()==customer2.getId()){
				customerExists = true;
				break;
			}
		}
		if(!customerExists){
			customers.add(customer);	
		}
		
		logger.info("Existing addCustomer()");

	}
	
	
	@RequestMapping(value = "/customer/updateCustomer", method = RequestMethod.PUT, consumes="application/json")
	public void updateCustomer(@RequestBody Customer customer) {
		logger.info("Inside updateCustomer()");
		
		
		for(Customer customer2 : customers){
			
			if(customer.getId()==customer2.getId()){
				
				customers.remove(customer2);
				customers.add(customer);
				break;
			}
		}
		
		logger.info("Existing updateCustomer()");

	}


}