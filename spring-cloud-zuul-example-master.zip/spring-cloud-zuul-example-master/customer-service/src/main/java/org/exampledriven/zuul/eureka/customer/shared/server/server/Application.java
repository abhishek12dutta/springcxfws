package org.exampledriven.zuul.eureka.customer.shared.server.server;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@EnableEurekaClient
@EnableWebMvc
@SpringBootApplication
@EnableDiscoveryClient
public class Application {

	private static Logger logger = LogManager.getLogger(Application.class);

	public static void main(String[] args) {
		logger.info("Starting Spring Boot customer-service application..");
		SpringApplication.run(Application.class, args);
	}

}
